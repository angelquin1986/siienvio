﻿Imports System.ComponentModel

Public Enum AmbienteType
    PRUEBA = 1
    PRODUCCION = 2
End Enum

Friend Enum AcctionType
    RECEPCION = 1
    AUTORIZACION = 2
End Enum

Friend Enum EnvioType
    NORMAL = 1
    LOTE = 2
    LOTE_MASIVO = 3
End Enum

Friend Enum EmisionType
    NORMAL = 1
    NODISPONIBLE = 2
End Enum